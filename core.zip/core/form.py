from django import forms
from .models import *

class SynergyApplicationForm(forms.ModelForm):
    class Meta:
        model = SynergyApplication
        fields = ['full_name', 'email', 'phone', 'pitch', 'cv']
