from django.http import JsonResponse
from django.shortcuts import render, redirect 
from django.core.paginator import Paginator
from .models import *
from .form import *
from django.contrib.auth.decorators import login_required


# Create your views here.

def msp_home(request):
    return render(request, 'core/msp_home.html')


def msp_admin(request):
    # if not request.user.is_authenticated or not request.user.is_staff:
    #     return redirect('login')

    # Fetch all users
    users = SynergyApplication.objects.all()

    # Pagination
    paginator = Paginator(users, 10)  # Show 10 users per page
    page_number = request.GET.get('page')
    users_page = paginator.get_page(page_number)

    context = {
        'users': users_page,
    }
    return render(request, 'core/msp_admin.html', context)

def msp_specialist(request):
    # if not request.user.is_authenticated or not request.user.is_staff:
    #     return redirect('login')

    # Fetch all users
    users = SynergyApplication.objects.all()

    # Pagination
    paginator = Paginator(users, 10)  # Show 10 users per page
    page_number = request.GET.get('page')
    users_page = paginator.get_page(page_number)

    context = {
        'users': users_page,
    }
    return render(request, 'core/msp_specialist.html', context)

def submit_synergy_application(request):
    if request.method == 'POST':
        form = SynergyApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return JsonResponse({'status': 'success', 'message': 'Application submitted successfully!'}, status=200)
        else:
            return JsonResponse({'status': 'error', 'errors': form.errors}, status=400)

    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)